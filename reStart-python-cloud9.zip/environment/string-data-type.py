myString = "This is a string"
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
firstString = "water"
secondString = "fall"
thrirdString = firstString + secondString
print(thrirdString)
name = input("what is yourname?")
print(name)
color = input("what is ypur favorite color? ")
animal = input("what is your favourite anima? ")
print("{}, you like a {} {}!".format(name,color,animal))